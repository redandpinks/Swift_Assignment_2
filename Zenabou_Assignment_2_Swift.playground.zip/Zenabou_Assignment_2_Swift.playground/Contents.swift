import Foundation

struct Location {
    let x: Int
    let y: Int
}
let storeRange = 2.5

let storeLocation1 = Location(x: 8, y: 8)
let storeLocation2 = Location(x: 3, y: 3)

struct Customer {
    var name: String
    var email: String
    var phoneNumber: String
    var acceptedNewsletter: Bool
    var location:Location
}
let Customers = [
    Customer(name: "John Bull", email: "Jbull@gmail.com", phoneNumber: "123456789", acceptedNewsletter: true, location: Location(x: 8, y: 8)),
    Customer(name: "Jay Jack", email: "JJ@yahoo.uk", phoneNumber: "23344556", acceptedNewsletter: false, location: Location(x: 3, y: 3)),
    Customer(name: "Mark Macys", email: "MacysM@gmail.com", phoneNumber: "45678932", acceptedNewsletter: false, location: Location(x: 3, y: 3)),
    Customer(name: "Mary Jay", email: "MaryJ@gmail.com", phoneNumber: "3344556678", acceptedNewsletter: true, location: Location(x: 8, y: 8)),
    Customer(name: "Gone Jack", email: "Gone@hotmail.com", phoneNumber: "233455677", acceptedNewsletter: true, location: Location(x: 3, y: 3)),
    Customer(name: "Mary May", email: "maym@hotmail.com", phoneNumber: "2342884144", acceptedNewsletter: false, location: Location(x: 3, y: 3)),
    Customer(name: "Usher Ray", email: "Ray@yahoo.com", phoneNumber: "7342884144", acceptedNewsletter: false, location: Location(x: 8, y: 8)),
    Customer(name: "Ray Jay", email: "Jay02@gmail.com", phoneNumber: "611523511", acceptedNewsletter: true, location: Location(x: 8, y: 8)),
    Customer(name: "Mic Brown", email: "Browns@gmail.com", phoneNumber: "4372998188", acceptedNewsletter: true, location: Location(x: 3, y: 3)),
    Customer(name: "Aliyah Mud ", email: "A.Mud@yahoo.uk", phoneNumber: "23442689", acceptedNewsletter: false, location: Location(x: 8, y: 8)),
    
    func printStoreLocation(storeLocation: Location)  {
        print("store Location: (\(storeLocation,x), \(storeLocation . y))")
    }

let storeLocation1 = Location(x: 8, y: 8)
    printStoreLocation(storeLocation: storeLocation1)
